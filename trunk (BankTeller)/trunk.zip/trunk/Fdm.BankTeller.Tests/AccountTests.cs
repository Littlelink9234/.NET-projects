﻿using System;
using System.Collections.Generic;
using System.Linq;
using Fdm.BankTeller.Main;
using NUnit.Framework;

namespace Fdm.BankTeller.Main
{
    [TestFixture]
    public class AccountTests
    {
        private readonly double INTEREST_RATE = 0.05;
        private readonly double SIX_HUNDRED = 600.0;
        private readonly double NEGATIVE_HUNDRED = -100.0;
        private readonly double FOUR_HUNDRED = 400.0;
        private readonly double THOUSAND_FIFTY = 1050.0;
        private readonly double NEG_FIFTY = -50.0;
        private readonly double FIFTY = 50.0;
        private readonly double TWELVE_HUNDRED = 1200.0;
        private readonly double THREE_FIFTEEN = 315.0;
        private readonly double ONE_HUNDRED = 100.0;
        private static readonly String INVALID_TEXT = "Invalid deposit amount.";
        private static readonly String INSUFFICIENT_AMOUNT = "Error: Insufficient amount.";
        private static readonly String INSUFFICIENT_DRAFT = "Error: You have exceeded your overdraft limit.";

        CurrentAccount cAccount = new CurrentAccount("Jason Carvalho", 1000.0, 1, 100);
        SavingsAccount sAccount = new SavingsAccount("Jon Melo", 300.0, 2);

        [Test]
        public void testDepositCurrentAccount()
        {
            cAccount = new CurrentAccount("Jason Carvalho", 1000.0, 1, 100);
            Console.WriteLine("testing deposit");
            double myResult = cAccount.deposit(FIFTY);      
            Assert.AreEqual(THOUSAND_FIFTY, myResult);
            Console.WriteLine(myResult);
        }

        [Test]
        public void testNegativeDepositCurrentAccount()
        {
            cAccount = new CurrentAccount("Jason Carvalho", 1000.0, 1, 100);
            Console.WriteLine("testing negative deposit");
            try
            {
                double result = cAccount.deposit(NEGATIVE_HUNDRED);
                Assert.Fail();
            }
            catch (AccountException e)
            {
                Assert.AreEqual(INVALID_TEXT, e.getText());
                Console.WriteLine(e.getText());
            }
        }

        [Test]
        public void testWithdrawCurrentAccount()
        {
            cAccount = new CurrentAccount("Jason Carvalho", 1000.0, 1, 100);
            Console.WriteLine("testing regular withdraw");
            double myResult = cAccount.withdraw(FOUR_HUNDRED);
            Assert.AreEqual(SIX_HUNDRED, myResult);
            Console.WriteLine(myResult);
        }

        [Test]
        public void testNegativeWithdrawCurrentAccount()
        {
            cAccount = new CurrentAccount("Jason Carvalho", 1000.0, 1, 100);
            Console.WriteLine("testing negative withdraw");
            try
            {
                double result = cAccount.withdraw(NEGATIVE_HUNDRED);
                Assert.Fail();
            }
            catch (AccountException e)
            {
                Assert.AreEqual(INSUFFICIENT_AMOUNT, e.getText());
                Console.WriteLine(e.getText());
            }
        }

        [Test]
        public void testWithdrawOverdraft()
        {
            cAccount = new CurrentAccount("Jason Carvalho", 1000.0, 1, 100);
            Console.WriteLine("testing withdraw overdraft");
            double myResult = cAccount.withdraw(THOUSAND_FIFTY);
            Assert.AreEqual(NEG_FIFTY, myResult);
            Console.WriteLine(myResult);
        }

        [Test]
        public void testWithdrawOverdraftLimit()
        {
            cAccount = new CurrentAccount("Jason Carvalho", 1000.0, 1, 100);
            Console.WriteLine("testing withdraw overdraft limit");
            try
            {
                double myResult = cAccount.withdraw(TWELVE_HUNDRED);
                Assert.Fail();
            }
            catch (AccountException e)
            {
                Assert.AreEqual(INSUFFICIENT_DRAFT, e.getText());
                Console.WriteLine(e.getText());
            }
        }

        [Test]
        public void testSavingsAccountAddInterest()
        {
            sAccount = new SavingsAccount("Jon Melo", 300.0, 2);
            Console.WriteLine("testing add interest to Savings account");
            double myResult = sAccount.addInterest(INTEREST_RATE);
            Assert.AreEqual(THREE_FIFTEEN, myResult);
            Console.WriteLine(myResult);
        }

        [Test]
        public void testDepositSavingsAccount()
        {
            sAccount = new SavingsAccount("Jon Melo", 300.0, 2);
            Console.WriteLine("testing deposit on Savings Account");
            double myResult = sAccount.deposit(ONE_HUNDRED);
            Assert.AreEqual(FOUR_HUNDRED, myResult);
            Console.WriteLine(myResult);
        }

        [Test]
        public void testNegativeDepositSavingsAccount()
        {
            sAccount = new SavingsAccount("Jon Melo", 300.0, 2);
            Console.WriteLine("testing negative deposit on Savings Account");
            try
            {
                double result = sAccount.deposit(NEGATIVE_HUNDRED);
                Assert.Fail();
            }
            catch (AccountException e)
            {
                Assert.AreEqual(INVALID_TEXT, e.getText());
                Console.WriteLine(e.getText());
            }
        }
    }
}
