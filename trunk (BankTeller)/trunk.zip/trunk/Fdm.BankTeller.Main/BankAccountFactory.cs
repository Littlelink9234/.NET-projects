﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fdm.BankTeller.Main
{
    class BankAccountFactory
    {
        private int accountNumber;
        public static readonly String ACCOUNT_ERROR = "Error: Invalid Account Type";

        public Account createAccount(String accountName, double balance, string accountType, double overdraft)
        {

            if (accountType == "Current")
            {
                return new CurrentAccount(accountName, balance, accountNumber, overdraft);
            }

            if (accountType == "Savings")
            {
                return new SavingsAccount(accountName, balance, accountNumber);
            }
            else
                throw new AccountException(ACCOUNT_ERROR);
        }
    }
}
