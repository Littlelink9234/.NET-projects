﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fdm.BankTeller.Main
{
    public class BankController : IBankController
    {
        public AccountOutput CreateSavingsAccount(string accountName, decimal openingBalance)
        {
            return null;
        }

        public AccountOutput CreateCurrentAccount(string accountName, decimal openingBalance, decimal overdraft)
        {
            return null;
        }

        public AccountOutput ViewAccount(string accountNumber)
        {
            return null;

        }

        public IList<AccountOutput> ViewAccounts()
        {
            return null;
        }

        public AccountOutput MakeTransactionRequest(TransactionRequest transactionRequest)
        {
            return null;
        }

        public void CloseAccount(string accountNumber)
        {

        }
    }
}
