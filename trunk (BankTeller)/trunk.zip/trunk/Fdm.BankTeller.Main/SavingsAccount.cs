﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fdm.BankTeller.Main
{
    public class SavingsAccount : Account
    {
        private readonly double INTEREST_RATE = 0.05;

        public SavingsAccount(string accountName, double balance, int accountNumber) :
            base(accountName, balance, accountNumber, "Savings")
        { 
        }

        public double addInterest(double balance)
        {
            base.balance = base.balance + (base.balance * INTEREST_RATE);

            return base.balance;
        }

        public override AccountOutput getFormat()
        {
            return new AccountOutput(base.accountName, base.balance.ToString(), base.accountNumber.ToString(), base.accountType,
                "0");
        }
    }
}
