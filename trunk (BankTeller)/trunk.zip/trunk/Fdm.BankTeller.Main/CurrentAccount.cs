﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fdm.BankTeller.Main
{
    public class CurrentAccount : Account
    {
        private double overdraft;

        public CurrentAccount(string accountName, double balance, int accountNumber, double overdraft) :
            base(accountName, balance, accountNumber, "Current")
        {
            this.overdraft = overdraft;
        }

        public override double withdraw(double amount)
        {
            if (amount <= 0)
            {
                throw new AccountException(INSUFFICIENT_AMOUNT);
            }
            else if (amount > (overdraft + base.getBalance))
            {
                throw new AccountException(INSUFFICIENT_DRAFT);
            }
            else if (base.balance + overdraft >= amount)
            {
                base.balance = base.balance - amount;
            }
            return base.getBalance;
        }

        public override AccountOutput getFormat()
        {
            return new AccountOutput(base.accountName, base.balance.ToString(), base.accountNumber.ToString(), base.accountType, 
                        overdraft.ToString());
        }
    }
}
