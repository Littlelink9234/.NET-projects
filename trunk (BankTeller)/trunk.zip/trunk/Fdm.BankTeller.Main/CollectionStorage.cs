﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fdm.BankTeller.Main
{
    public class CollectionStorage
    {
        private static Dictionary<int, Account> accounts = new Dictionary<int,Account>();
        
        public void createAccount(Account account)
        {
            accounts.Add(account.getAccountNumber, account);
        }

        public Account readAccount(int AccountNumber)
        {
            return accounts[AccountNumber];
        }

        public void updateAccount(int accountNumber, string transactionType, double amount)
        {
            if (transactionType == "Deposit")
            {
                accounts[accountNumber].deposit(amount);
            }
            else
            {
                accounts[accountNumber].withdraw(amount);
            }
        }

        public void deleteAccount(int AccountNumber)
        {
            accounts.Remove(AccountNumber);
        }

        public IList<AccountOutput> viewAllAccounts()
        {
            IList<AccountOutput> accOutputs = new List<AccountOutput>();
            foreach (KeyValuePair<int, Account> account in accounts)
            {
                accOutputs.Add(account.Value.getFormat());
            }
            return accOutputs;
        }
    }
}
