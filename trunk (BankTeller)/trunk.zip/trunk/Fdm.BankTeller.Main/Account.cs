﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fdm.BankTeller.Main
{
    public abstract class Account
    {
        public static readonly String INVALID_TEXT = "Invalid deposit amount.";
        public static readonly String INSUFFICIENT_AMOUNT = "Error: Insufficient amount.";
        public static readonly String INSUFFICIENT_FUNDS = "Error: Insufficient funds.";
        public static readonly String INSUFFICIENT_DRAFT = "Error: You have exceeded your overdraft limit.";
        public string accountName;
        public double balance;
        public int accountNumber;
        public string accountType;

        public Account(string accountName, double balance, int accountNumber, string accountType)
        {
            this.accountName = accountName;
            this.balance = balance;
            this.accountNumber = accountNumber;
            this.accountType = accountType;
        }

        public string getAccountName
        {
            get { return accountName; }
        }

        public double getBalance
        {
            get { return balance; }
        }

        public int getAccountNumber
        {
            get { return accountNumber; }
        }

        public abstract AccountOutput getFormat();

        public double deposit(double amount)
        {
            if (amount < 0)
            {
                throw new AccountException(INVALID_TEXT);
            }
            else
            {
                this.balance = this.balance + amount;
            }
            return this.balance;
        }

        public virtual double withdraw(double amount)
        {
            if (amount < 0)
            {
                throw new AccountException(INSUFFICIENT_AMOUNT);
            }
            else if (amount > this.balance)
            {
                throw new AccountException(INSUFFICIENT_FUNDS);
            }
            else
            {
                balance = balance - amount;
            }
            return balance;
        }
    }
}
